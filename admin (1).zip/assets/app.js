// Close user dropdown on outside click
document.addEventListener('click', function (e) {
    var dd = document.querySelector('.user-dropdown');
    if (dd && dd.classList.contains('open') && !e.target.closest('.user-menu')) {
        dd.classList.remove('open');
    }
});

// Like video (watch page)
function likeVideo(videoId) {
    var btn = document.getElementById('likeBtn');
    fetch(window.location.pathname, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=like&id=' + encodeURIComponent(videoId)
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
        if (data.success) {
            document.getElementById('likeCount').textContent = data.likes;
            if (btn) btn.classList.toggle('liked', data.liked);
        } else if (data.message) {
            alert(data.message);
        }
    });
}

// Like comment
function likeComment(commentId) {
    fetch(window.location.pathname, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=like_comment&comment_id=' + encodeURIComponent(commentId)
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
        if (data.success) {
            var el = document.getElementById('commentLikes-' + commentId);
            if (el) el.textContent = data.likes;
        } else if (data.message) {
            alert(data.message);
        }
    });
}

// Enable comment submit button when text is present
document.addEventListener('DOMContentLoaded', function () {
    var ta = document.getElementById('commentText');
    var btn = document.getElementById('submitBtn');
    if (ta && btn) {
        ta.addEventListener('input', function () {
            btn.disabled = ta.value.trim().length === 0;
        });
    }
});
