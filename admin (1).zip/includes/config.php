<?php
// ==========================================
// SITE CONFIGURATION
// ==========================================
// Edit database credentials for your cPanel MySQL database

define('DB_HOST', 'localhost');
define('DB_NAME', 'jhrgeenn_Reelvideo6');
define('DB_USER', 'jhrgeenn_Reelvideo6');
define('DB_PASS', 'Qhy0B[sV}=J7BXpO');

// Base URL of the site WITHOUT trailing slash (used for SEO tags & sitemap)
define('SITE_URL', 'https://virallinx.site');

// Default admin credentials (created automatically on first run).
// CHANGE THE PASSWORD after first login from Admin > Users.
define('DEFAULT_ADMIN_EMAIL', 'admin@virallinx.site');
define('DEFAULT_ADMIN_PASS', 'admin123');
