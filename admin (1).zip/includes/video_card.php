<?php // Expects $v (video row, optionally with category_name) ?>
<a href="<?php echo video_url($v); ?>" class="video-card">
    <?php if (!empty($v['category_name'])): ?>
        <span class="card-cat"><?php echo e($v['category_name']); ?></span>
    <?php endif; ?>
    <div class="thumb-wrapper">
        <img src="<?php echo e($v['thumbnail_url']); ?>" alt="<?php echo e($v['title']); ?>" loading="lazy">
        <div class="play-icon">
            <div class="glass-circle">
                <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            </div>
        </div>
    </div>
    <div class="card-details">
        <div class="card-title"><?php echo e($v['title']); ?></div>
        <div class="card-meta">
            <span><?php echo format_count($v['views']); ?> views</span>
            <span>•</span>
            <span>❤ <?php echo format_count($v['likes'] ?? 0); ?></span>
            <span>•</span>
            <span><?php echo time_ago($v['created_at']); ?></span>
        </div>
    </div>
</a>
