<?php
// Generic video listing renderer.
// Expects: $listing_title, $order_by (safe SQL), optional $listing_base_url
require_once __DIR__ . '/db.php';

$per_page = 24;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;
$cat_id = intval($_GET['cat'] ?? 0);
$q = trim($_GET['q'] ?? '');

$where = "WHERE v.status = 'published'";
$params = [];
if ($cat_id) { $where .= " AND v.category_id = ?"; $params[] = $cat_id; }
if ($q !== '') { $where .= " AND (v.title LIKE ? OR v.description LIKE ?)"; $params[] = "%$q%"; $params[] = "%$q%"; }

$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM videos v $where");
$count_stmt->execute($params);
$total = $count_stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT v.*, c.name AS category_name FROM videos v LEFT JOIN categories c ON v.category_id = c.id $where ORDER BY $order_by LIMIT $per_page OFFSET $offset");
$stmt->execute($params);
$videos = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

$page_title = $listing_title . ' — ' . setting('site_name', 'ViralLinx');
$page_description = $listing_title . ' videos on ' . setting('site_name', 'ViralLinx') . '. Watch trending AI movies, viral videos and stories in high quality.';
require __DIR__ . '/header.php';

$base = $listing_base_url ?? strtok($_SERVER['REQUEST_URI'], '?');
$qs = [];
if ($cat_id) $qs[] = 'cat=' . $cat_id;
if ($q !== '') $qs[] = 'q=' . urlencode($q);
$paginate_url = $base . ($qs ? ('?' . implode('&', $qs)) : '');
?>

<div class="section-header">
    <h2 class="section-title"><?php echo e($listing_title); ?><?php if ($q !== '') echo ' for "' . e($q) . '"'; ?></h2>
    <span style="color:var(--text-secondary);font-size:14px;"><?php echo number_format($total); ?> videos</span>
</div>

<?php if (!empty($categories)): ?>
<div class="cat-pills">
    <a href="<?php echo e($base); ?>" class="cat-pill <?php echo !$cat_id ? 'active' : ''; ?>">All</a>
    <?php foreach ($categories as $cat): ?>
        <a href="<?php echo e($base . '?cat=' . $cat['id']); ?>" class="cat-pill <?php echo $cat_id == $cat['id'] ? 'active' : ''; ?>"><?php echo e($cat['name']); ?></a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php echo render_ads('between_grid'); ?>

<?php if (!empty($videos)): ?>
    <div class="video-grid">
        <?php foreach ($videos as $v) include __DIR__ . '/video_card.php'; ?>
    </div>
    <?php echo paginate($total, $per_page, $page, $paginate_url); ?>
<?php else: ?>
    <div class="empty-state">
        <h3>No videos found</h3>
        <p>Try a different keyword or category.</p>
    </div>
<?php endif; ?>

<?php require __DIR__ . '/footer.php'; ?>
