<?php
// Expects optional: $page_title, $page_description, $page_canonical, $og_image
$site_name = setting('site_name', 'ViralLinx');
$page_title = $page_title ?? setting('seo_home_title', $site_name . ' - Watch AI Movies & Stories');
$page_description = $page_description ?? setting('seo_home_description', 'Watch trending AI movies, viral videos and stories in high quality on ' . $site_name . '.');
$page_canonical = $page_canonical ?? canonical_url($_SERVER['REQUEST_URI'] ?? '/');
$og_image = $og_image ?? setting('seo_default_image', '');
$user = current_user();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page_title); ?></title>
    <meta name="description" content="<?php echo e($page_description); ?>">
    <?php if (setting('seo_keywords')): ?><meta name="keywords" content="<?php echo e(setting('seo_keywords')); ?>"><?php endif; ?>
    <link rel="canonical" href="<?php echo e($page_canonical); ?>">
    <meta name="robots" content="index, follow">
    <!-- Open Graph -->
    <meta property="og:site_name" content="<?php echo e($site_name); ?>">
    <meta property="og:title" content="<?php echo e($page_title); ?>">
    <meta property="og:description" content="<?php echo e($page_description); ?>">
    <meta property="og:url" content="<?php echo e($page_canonical); ?>">
    <meta property="og:type" content="<?php echo isset($og_type) ? e($og_type) : 'website'; ?>">
    <?php if ($og_image): ?><meta property="og:image" content="<?php echo e($og_image); ?>"><?php endif; ?>
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($page_title); ?>">
    <meta name="twitter:description" content="<?php echo e($page_description); ?>">
    <?php if ($og_image): ?><meta name="twitter:image" content="<?php echo e($og_image); ?>"><?php endif; ?>
    <?php if (setting('google_site_verification')): ?><meta name="google-site-verification" content="<?php echo e(setting('google_site_verification')); ?>"><?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/style.css?v=2">
    <?php if (isset($extra_head)) echo $extra_head; ?>
    <?php echo setting('google_analytics_code'); ?>
    <?php echo setting('header_code'); ?>
    <?php echo render_ads('header', false); ?>
</head>
<body>

<header class="navbar">
    <a href="<?php echo url(''); ?>" class="brand-logo">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 6.5C4 4.567 5.567 3 7.5 3H16.5C18.433 3 20 4.567 20 6.5V17.5C20 19.433 18.433 21 16.5 21H7.5C5.567 21 4 19.433 4 17.5V6.5Z" stroke="url(#paint0_linear)" stroke-width="2"/>
            <path d="M10 9L15 12L10 15V9Z" fill="url(#paint0_linear)"/>
            <defs>
                <linearGradient id="paint0_linear" x1="4" y1="3" x2="20" y2="21" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#6366f1"/>
                    <stop offset="1" stop-color="#a855f7"/>
                </linearGradient>
            </defs>
        </svg>
        <?php
        $brand = setting('site_name', 'ViralLinx');
        $half = ceil(strlen($brand) / 2);
        echo e(substr($brand, 0, $half)) . '<span>' . e(substr($brand, $half)) . '</span>';
        ?>
    </a>

    <nav class="nav-links">
        <a href="<?php echo url(''); ?>">Home</a>
        <a href="<?php echo url('browse'); ?>">Browse</a>
        <a href="<?php echo url('popular'); ?>">Popular</a>
        <a href="<?php echo url('new'); ?>">New</a>
        <a href="<?php echo url('most-liked'); ?>">Most Liked</a>
        <a href="<?php echo url('random'); ?>">🎲 Random</a>
    </nav>

    <form class="search-box" method="GET" action="<?php echo url('search'); ?>">
        <input type="text" name="q" placeholder="Search movies, stories..." value="<?php echo e($_GET['q'] ?? ''); ?>">
        <button type="submit" aria-label="Search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
        </button>
    </form>

    <div class="nav-auth">
        <?php if ($user): ?>
            <div class="user-menu">
                <button class="user-chip" onclick="document.querySelector('.user-dropdown').classList.toggle('open')">
                    <span class="avatar" style="background:<?php echo e($user['avatar_color']); ?>"><?php echo e(strtoupper(substr($user['username'], 0, 1))); ?></span>
                    <?php echo e($user['username']); ?>
                </button>
                <div class="user-dropdown">
                    <a href="<?php echo url('profile'); ?>">My Profile</a>
                    <?php if ($user['role'] === 'admin'): ?><a href="<?php echo url('admin'); ?>">Admin Panel</a><?php endif; ?>
                    <a href="<?php echo url('logout'); ?>">Logout</a>
                </div>
            </div>
        <?php else: ?>
            <a href="<?php echo url('login'); ?>" class="auth-btn">Sign In</a>
            <a href="<?php echo url('register'); ?>" class="auth-btn primary">Register</a>
        <?php endif; ?>
    </div>
    <button class="mobile-toggle" onclick="document.querySelector('.navbar').classList.toggle('mobile-open')" aria-label="Menu">☰</button>
</header>

<main class="main-container">
