==========================================
 ViralLinx — Premium Video Platform (PHP)
==========================================

INSTALLATION (cPanel)
---------------------
1. Upload ALL files (including the hidden .htaccess) to public_html.
2. Edit includes/config.php:
   - Database host, name, user, password (your existing DB works — tables
     are created/upgraded automatically on first visit).
   - SITE_URL: your domain (used for SEO tags & sitemap).
3. Visit your site once — the database schema is auto-created/migrated.
4. Log in to the admin panel at:  https://yourdomain.com/admin
   Default login:  admin@virallinx.site  /  admin123
   >>> CHANGE THIS PASSWORD IMMEDIATELY (Admin > Users > Reset Password).

CLEAN URLS (no .php)
--------------------
Handled by .htaccess (Apache mod_rewrite — enabled on cPanel by default):
  /                      Home
  /browse /popular /new /most-liked /random /search?q=...
  /watch/123/video-title-slug
  /login /register /logout /profile
  /page/about-us         Static pages
  /admin                 Admin panel
  /sitemap.xml           Auto-generated XML sitemap
Old links like /watch.php?id=5 are 301-redirected to the new URLs.

FEATURES
--------
Public: user registration/login, per-user likes (like/unlike), comments,
watch history, liked videos, profile, category filters, pagination,
search, random video, popular/new/most-liked pages, share buttons
(WhatsApp/Facebook/X/copy), mobile responsive.

SEO: clean URLs with slugs, canonical tags, meta title/description per
video, Open Graph + Twitter cards, VideoObject JSON-LD structured data,
XML sitemap, robots.txt, Google Search Console verification field,
301 redirects from old URLs.

Admin (/admin): dashboard with metrics, video manager (add/edit/delete,
bulk actions, drafts, featured hero video, per-video SEO fields),
categories, comment moderation (approve/spam/delete), full user
management (create, ban, promote to admin, reset password, delete),
static page builder (About/Privacy/DMCA...), CSV export, and a complete
Ads Manager:
  - Header code (Google AdSense auto ads / any script into <head>)
  - Footer code
  - Google Analytics / Tag Manager code
  - Banner ad units by placement: header, footer, below player,
    above grid, sidebar, popup, popunder, custom
  - Popup modal ads with frequency + delay control
  - Popunder ads with frequency control
  - Pause/activate any ad unit with one click

SECURITY
--------
Passwords hashed (bcrypt), PDO prepared statements everywhere, CSRF
tokens on forms, includes/ directory blocked from direct access,
admin panel noindex, security headers in .htaccess.
